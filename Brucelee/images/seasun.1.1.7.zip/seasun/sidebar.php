<?php
/**
 * The sidebar template file.
 * @package SeaSun
 * @since SeaSun 1.0.0
*/
?>
<aside id="sidebar">
<?php if ( dynamic_sidebar( 'sidebar-1' ) ) : else : ?>
<?php endif; ?>
</aside> <!-- end of sidebar -->